//Initialization
var config = {
        mode: {name: "python", version: 2, singleLineStringErrors: false},
        theme: "ambiance",
        lineNumbers: true,
        smartIndent: true,
        indentWithTabs: true,
        indentUnit:4,
        electricChars: true,
        autoClearEmptyLines: true,
        lineWrapping: false,
        tabMode: "shift",
        matchBrackets: true,
        undoDepth: 100
     }; 
var editor = CodeMirror.fromTextArea(document.getElementById("code"), config);

//Block Visualizer
function howManyTabs(x){
	try{
		var i=0
		while(x[i]==='\t') i++;
		return i;
	}catch(err){
		console.log(err)
		return 0
	}
}
function setBackgroundForIndent(x, y){
	for(var i=y.from.line; i<=y.to.line; i++){
		var line=editor.getLine(i)
		var tbCount=howManyTabs(line)
		if(tbCount>0){
			editor.setLineClass(i, null, 'indent'+tbCount)
			for(var j=0; j<tbCount; j++)
				editor.markText({line:i,ch:j}, {line:i,ch:(j+1)}, 'indent'+j, null)
		}else
			editor.setLineClass(i, null, null)
	}
}
function blockVisualizer(){
	var i=editor.getCursor(false).line
	var line=editor.getLine(i)
	var tbCount=howManyTabs(line)
	if(tbCount>0){
		editor.setLineClass(i, null, 'indent'+tbCount)
		for(var j=0; j<tbCount; j++)
			editor.markText({line:i,ch:j}, {line:i,ch:(j+1)}, 'indent'+j, null)
	}else
			editor.setLineClass(i, null, null)
}

//Auto Completion
var wordList=['print', 'for', 'while'];
var option={
	source:wordList
};

//$('.variable').typeahead(option)

function onCursorActivity(){
	blockVisualizer()
	token=editor.getTokenAt(editor.getCursor(false))
	console.log(editor.getTokenAt(editor.getCursor(false)))
	
}

//Binding
editor.setOption('onChange',setBackgroundForIndent)
editor.setOption('onCursorActivity',onCursorActivity)


