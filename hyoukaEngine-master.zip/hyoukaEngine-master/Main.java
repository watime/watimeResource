import java.io.*;

public class Main {

    public static void main(String[] args) {
        try {

            FileReader f = new FileReader("/Users/ray/zhwiki.xml");
            FileWriter writer = new FileWriter("zhwikiProcessed.txt");
            BufferedReader b = new BufferedReader(f);
            BufferedWriter w = new BufferedWriter(writer);
            String line = "";
            String[] spline;
            int counter = 0;
            int m = 100000;

            while (true) {
                try {

                    try {
                        line = b.readLine();
                    } catch (IOException e) {
                        e.printStackTrace();
                        break;
                    }

                    //粗體
                    spline = line.split("'''");
                    for (int j = 1; j < spline.length && spline.length > 2; j += 2) {
                        String token = spline[j];
                        for (String tok : split(token))
                            if (judge(tok))
                                w.write(cleanUp(tok) + "\n");
                    }
                    //項目
                    if (line.length() > 2)
                        if (line.substring(0, 1).equals(";") || line.substring(0, 1).equals("#") || line.substring(0, 1).equals("*"))
                            for (String tok : split(line))
                                if (judge(tok) && judge(cleanUp(tok)))
                                    w.write(cleanUp(tok) + "\n");

                } catch (Exception e) {
                    e.printStackTrace();  //To change body of catch statement use File | Settings | File Templates.
                    break;

                }

                if (--m == 0) {
                    m = 100000;
                    counter++;
                    System.out.println(new Integer(counter / 10) + "." + new Integer(counter % 10) + "M");
                }

            }
            w.close();
            f.close();
            writer.close();
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    static String cleanUp(String s) {
        String[] list = {";", " ", "'", "「", "」", "“", "”", "'", "《", "》", "\\*", "\\#", "？", "\\(", "\\)", ":", "；"};
        for (String i : list) s = s.replaceAll(i, "");
        return s;
    }

    static boolean judge(String s) {
        if (s.length() > 10 || s.length() < 2) return false;
        String[] alpha = {"a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k", "l", "m", "n", "o", "p", "q", "r", "s", "t", "u", "v", "w", "x", "y", "z"};
        String[] num = {"1", "2", "3", "4", "5", "6", "7", "8", "9", "0", "=", "+", "-", "_", "[", "]"};
        String[] dot = {"，", "。", "、", "'", "\\'"};
        for (String x : alpha) {
            if (s.contains(x)) return false;
            if (s.contains(x.toUpperCase())) return false;
        }
        for (String x : num) if (s.contains(x)) return false;
        for (String x : dot) if (s.contains(x)) return false;

        return true;
    }

    static String[] split(String s) {
        String[] list = {"\\|", "／", "/", "（", "）", "：", "\\{", "}"};
        for (String i : list) s = s.replaceAll(i, "XXX");
        return s.split("XXX");
    }
}
