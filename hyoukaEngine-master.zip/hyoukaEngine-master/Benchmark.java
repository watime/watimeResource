import org.sqlite.SQLiteConfig;
import org.sqlite.SQLiteDataSource;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.concurrent.Executor;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ThreadPoolExecutor;

public class Benchmark {
    static Connection conn;
    static Long start, end, start2, end2;
    static String timerString = "", timerString2 = "";
    static ResultSet cursor;
    static String temp = "";
    static Statement db;

    public static void main(String[] args) {

        try {
            initializeDatabase();
            db = conn.createStatement();
//            test("select zi from solo where pinyin glob 'Aa' and zi glob '?'");
//            test("select zi from solo where pinyin like 'Aa' and zi like '_'");
//            test("select zi from solo where pinyin like '__' and zi like '的'");
//            test("select zi from solo where pinyin glob '??' and zi glob '的'");

//            test("select zi from solo where zi glob '的' and pinyin glob '??'");
//            test("select zi from solo where pinyin glob 'Aa' and zi glob '?' union all select zi from solo where pinyin glob '??' and zi glob '的'");
//            test("(select zi from solo where pinyin glob 'Aa' and zi glob '?' limit 1) union all (select zi from solo where pinyin glob '??' and zi glob '的' limit 1)");
//            test("select zi from solo where (pinyin glob 'Aa' and zi glob '?') or (pinyin glob '??' and zi glob '的')");
//            test("select zi from solo where pinyin glob 'Aa' and zi glob '?' limit 1");
//            test("select zi,priority from solo where pinyin glob 'Aa' and zi glob '?' order by priority desc");

//            startTimer("begin transaction");
//            db.execute("begin transaction");
//            endTimer();
//            test("select zi from solo where pinyin glob 'Aa' and zi glob '?'");
//            test("select zi from solo where pinyin glob '??' and zi glob '的'");
//            startTimer("end transaction");
//            db.execute("end transaction");
//            endTimer();

//            test("select zi from solo where pinyin glob 'Aa' and zi glob '?'" + " union all " +
//                    "select zi from solo where pinyin glob '??' and zi glob '的'");
			Timer t=new Timer("");
	        t.str="unthreaded";
	        final String s="123456789";
	        t.start();
	        for (int j=0; j<10;j++) {
		        for (int i = 0; i < 9; i++) {
			        s.substring(i,9);
		        }
	        }
	        t.stop();
	        t.start();
	        for (int j=0; j<10;j++) {
		        for (int i = 0; i < 9; i++) {
			        s.substring(i,9);
		        }
	        }
	        t.stop();
	        t.str="executor";
	        t.start();
	        Executor pool = Executors.newCachedThreadPool();
	        t.stop();
	        t.str="runnable";
	        t.start();
			Runnable r1=new Runable1("r1");
			Runnable r2=new Runable1("r2");
	        t.stop();
	        t.str="execute";
	        t.start();
	        pool.execute(r1);
	        pool.execute(r2);
	        t.stop();
	        try {
		        Thread.sleep(100);
	        } catch (InterruptedException e) {
		        e.printStackTrace();  //To change body of catch statement use File | Settings | File Templates.
	        }
	        t.start();
	        pool.execute(r1);
	        pool.execute(r2);
	        t.stop();


        } catch (SQLException e) {
            e.printStackTrace();  //To change body of catch statement use File | Settings | File Templates.
        }

    }

    static void endTimer() {
        end = System.nanoTime();
        System.out.print((end - start) / 1000);
        System.out.println("\t" + timerString);
    }

    static void startTimer(String s) {
        timerString = s;
        start = System.nanoTime();
    }

    static void initializeDatabase() {
        SQLiteConfig config = new SQLiteConfig();
        config.setReadOnly(true);
        config.setCacheSize(0);
        config.setSharedCache(false);

        SQLiteDataSource source = new SQLiteDataSource(config);
        source.setUrl("jdbc:sqlite:magician.db3");

        try {
            conn = source.getConnection();
        } catch (SQLException e) {
            e.printStackTrace();
            assert false;
        }
    }

    static void test(String query) {
        try {
            System.out.println("\n" + query);
            startTimer("return cursor");
            cursor = db.executeQuery(query);
            endTimer();

            startTimer("move cursor to first");
            cursor.next();
            endTimer();

            startTimer("get zi");
            temp = cursor.getString(1);
            endTimer();

            System.out.println("output: " + temp);
            startTimer("Read all cursor");
            while (cursor.next()) temp = cursor.getString(1);
            endTimer();
        } catch (SQLException e) {
            e.printStackTrace();  //To change body of catch statement use File | Settings | File Templates.
        }
    }


}

class X {
    final int a[];
    final int length;
    int pointer = 0;

    public X(String s) {
        a = new int[s.length()];
        length = s.length();
        for (int i = 0; i < s.length(); i++)
            a[i] = Integer.parseInt(s.substring(i, i + 1));
    }

    public boolean hasNext() {
        if (pointer < length) return true;
        else return false;
    }

    public int next() {
        return a[pointer++];
    }

    public void reset() {
        pointer = 0;
    }
}

class Timer {
    long startTime, end;
    String str;
    public Timer(String s){
        str=s;
    }
    public void start(){
        startTime = System.nanoTime();
    }
	public void stop(){
		end=System.nanoTime();
		System.out.print(str+": \t");
		System.out.println((end - startTime) / 1000);
	}
}

class QueryTester implements Runnable {
	Timer t;
	String queryStr;

	ResultSet cursor;
	public QueryTester(String s){
		t=new Timer("");
		queryStr = s;
	}
	public void run(){
		System.out.println(queryStr);
		t.str="return cursor";
		t.start();
//		cursor =
	}
}
class Runable1 implements Runnable{
	Timer t;
	public Runable1(String s){
		t=new Timer(s);
	}
	public void run(){
		final String s="123456789";
		t.start();
		for (int j=0; j<10;j++) {
			for (int i = 0; i < 9; i++) {
				s.substring(i,9);
			}
		}
		t.stop();
	}
}