public class IceCreamEngine {
	static final int separator[][][] = Constants.separator; // [word length - 1][separator list][separator atom]
	static String pinyin, oldPinyin;
	static String queryResultL[][] = initQueryResult(9); // [length][start at]
	static String queryResultD[][] = initQueryResult(9);
	static String candidateLeft[], candidateRight[];
	static String ziLock[] = new String[9], ziUnlock[] = new String[9];
	static int separatorAnswer[];
	static String sentence;

	public static void main(String[] args) {
		Timer t = new Timer("");
		pinyin = "Aa";
		oldPinyin = "AaBb";

		t.start();
		try {
			chitanda();
		} catch (Exception e) {
			e.printStackTrace();  //To change body of catch statement use File | Settings | File Templates.
		}
		t.stop();
//		for (int i : separatorAnswer) System.out.print(i);
//		System.out.println(sentence);
	}

	public static void chitanda() throws Exception {
		if (pinyin.length() % 2 != 0) throw new Exception("pinyin length is not even");
		if (oldPinyin.equals(pinyin.substring(0, pinyin.length() - 2))) {
			System.out.println("case add 1 chara");
		} else if (pinyin.equals(oldPinyin.substring(0, oldPinyin.length() - 2))) {
			System.out.println("case delete 1 chara");
		} else if (oldPinyin.endsWith(pinyin) && (oldPinyin.length() - pinyin.length()) > 0) {
			System.out.println("pop");
		}else throw new Exception("no matched case");
	}

	public static void oreki(int length) throws Exception { //Todo: remove length argument
		boolean found;
		int counter;
		for (int[] a : separator[length - 1]) {
			found = true;
			counter = 0;
			for (int b : a) {
				if (queryResultL[b][counter] == null && queryResultD[b][counter] == null) {
					found = false;
					break;
				}
				counter += b;
			}
			if (found) {
				separatorAnswer = a;
				return;
			}
		}
		throw new Exception("No matched separator");
	}

	public static void houtarou() {
		StringBuffer sb = new StringBuffer();
		int counter = 0;
		for (int i : separatorAnswer) {
			sb.append(queryResultL[i][counter] == null ? queryResultD[i][counter] : queryResultL[i][counter]);
			counter += i;
		}
		sentence = sb.toString();
	}

	public static String[][] initQueryResult(int length) {
		String x[][] = new String[length + 1][];
		for (int i = 1; i <= length; i++)
			x[i] = new String[length - i + 1];
		x[0] = new String[0];
		return x;
	}
}
