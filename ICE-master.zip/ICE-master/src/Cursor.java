import java.sql.ResultSet;
import java.sql.SQLException;

final public class Cursor {
	final ResultSet rs;

	public Cursor(final ResultSet x) {
		rs = x;
	}

	public boolean next() {
		try {
//			long t=System.nanoTime();
			boolean b=rs.next();
//			System.out.print((System.nanoTime() - t) / 1000);
//			System.out.println("   \t>>> next");
			return b;
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return false;
	}

	public String getString(int i) {
		try {
			return rs.getString(i+1);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return null;
	}

	public int getInt(int i) {
		try {
			return rs.getInt(i+1);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return -65536;
	}

	public void close(){
		try {
			rs.close();
		} catch (SQLException e) {
			e.printStackTrace();  //To change body of catch statement use File | Settings | File Templates.
		}
	}
}