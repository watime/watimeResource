import org.sqlite.SQLiteConfig;
import org.sqlite.SQLiteDataSource;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class Connection {
	SQLiteConfig config = new SQLiteConfig();
	java.sql.Connection conn;
	Statement db;
	ResultSet rs;

	public Connection() {
		config.setCacheSize(0);
		config.setSharedCache(false);
		config.setReadOnly(true);
		SQLiteDataSource source = new SQLiteDataSource(config);
		source.setUrl("jdbc:sqlite:magician.db3");
		try {
			conn = source.getConnection();
			db = conn.createStatement();
		} catch (SQLException e) {
			e.printStackTrace();
			assert false;
		}
	}

	public void executeUpdate(String s) {
		try {
			db.executeUpdate(s);
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public void executeUpdate(String s, String[] ss) {
		try {
			db.executeUpdate(s, ss);
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public Cursor executeQuery(String s) {
		try {
			long t = System.nanoTime();
			ResultSet rs=db.executeQuery(s);
			System.out.print((System.nanoTime() - t) / 1000);
			System.out.println(" \t>>> " + s);
			t = System.nanoTime();
			Cursor c = new Cursor(rs);
			System.out.print((System.nanoTime() - t) / 1000);
			System.out.println(" \t>>> " + "cursor");
			return c;
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return null;
	}
}

