import java.util.Scanner;

public class Main {
	static IceCreamEngine ice = new IceCreamEngine();

	public static void main(String[] args) {

//		long t = System.nanoTime();

		Scanner scn = new Scanner(System.in);
		String in = "y";
		ice.pinyin = "";

		while (!in.contains("n")) {
			if (in.contains("pop")) {
				System.out.print("how many to pop? ");
				int x = Integer.parseInt(scn.nextLine());
				ice.pinyin = ice.pinyin.substring(2 * x);
				ice.ziLock = ice.ziLock.substring(x);
				ice.ziOrig = ice.ziOrig.substring(x);
			} else if (in.contains("del")) {
				ice.pinyin = ice.pinyin.substring(0, ice.pinyin.length() - 2);
				ice.ziLock = ice.ziLock.substring(0, ice.ziLock.length() - 1);
				ice.ziOrig = ice.ziOrig.substring(0, ice.ziOrig.length() - 1);
			} else {
				System.out.print("Enter new pinyin: ");
				ice.pinyin += scn.nextLine();
//				System.out.print("Enter new ziLock: ");
//				ice.ziLock += scn.nextLine();
				ice.ziLock += "?";
				ice.ziOrig = ice.ziLock;
			}

			System.out.println("status: ");
			System.out.println("pinyin = " + ice.pinyin);
			System.out.println("ziLock = " + ice.ziLock);
//			System.out.println("ziOrig = " + ice.ziOrig);

			// Process here
			try {
				long start = System.nanoTime();
				ice.decideCaseAndMove();
				long stop = System.nanoTime();
				System.out.print("chitanda = ");
				System.out.println((stop - start) / 1000);

				start = System.nanoTime();
				ice.makeSeparatorAnswer();
				ice.makeSentence();
				ice.makeCandidate();
				stop = System.nanoTime();
				System.out.print("oreki = ");
				System.out.println((stop - start) / 1000);

				System.out.println(ice.sentence);
			} catch (Exception e) {
				e.printStackTrace();
			}
			for (int i = 0; i < ice.queryResultD.length; i++)
				try {
					for (int j = 0; j < ice.queryResultD[i].length; j++)
						try {
							if (ice.queryResultD[i][j] != null) {
								System.out.print("[");
								System.out.print(i);
								System.out.print("][");
								System.out.print(j);
								System.out.print("] = ");
								System.out.println(ice.queryResultD[i][j]);
							}
						} catch (Exception e) {
						}
				} catch (Exception e) {
				}
			System.out.print("LEFT:  ");
			for (String s: ice.candidateLeft)
				System.out.print(s + "  ");
			System.out.print("\nRIGHT: ");
			for (String s: ice.candidateRight)
				System.out.print(s+"  ");
			// Process end
			System.out.println("continue?");
			System.gc();
			in = scn.nextLine();
		}

//		try {
//			ice.query();
//		} catch (Exception e) {
//			e.printStackTrace();
//		}
//		System.out.print((System.nanoTime() - t) / 1000);
	}
}
