import java.util.LinkedList;

public class IceCreamEngine {
	static Connection conn = new Connection();
	static final int separator[][][] = Constants.separator; // [word length - 1][separator list][separator atom]
	static final String[] type = {"concerto", "solo", "duet", "trio", "quartet"};
	static final String s1 = "select length(zi), zi, priority from ",
			s2 = " where pinyin glob '",
			s3 = "' and zi glob '",
			s4 = "'",
			s5 = " union all ",
			s6 = " order by length(zi) desc, priority desc";
	public static String pinyin = "";
	static String oldPinyin = "";
	static LinkedList<String>[][] queryResultL = initQueryResult(9); // [length][start at][i]  // learning
	static LinkedList<String>[][] queryResultD = initQueryResult(9); // [length][start at][i]  // dictionary
	public static LinkedList<String> candidateLeft, candidateRight;
	public static String ziLock = ""; // after dict select or direct zi input
	public static String ziOrig = ""; // before dict select
	public static int separatorAnswer[];
	public static String sentence;

	public static LinkedList<String>[][] initQueryResult(int length) {
		LinkedList<String>[][] x = new LinkedList[length + 1][];
		for (int i = 1; i <= length; i++)
			x[i] = new LinkedList[length - i + 1];
		return x;
	}

	public static void decideCaseAndMove() throws Exception {
		if (pinyin.length() % 2 != 0) throw new Exception("pinyin length is not even");

		try {
			if (oldPinyin.equals(pinyin.substring(0, pinyin.length() - 2))) {
//				System.out.println("case add 1 chara");
				query();
				oldPinyin = pinyin;
				return;
			}
		} finally {
		}

		try {
			if (pinyin.equals(oldPinyin.substring(0, oldPinyin.length() - 2))) {
//				System.out.println("case delete 1 chara");
				final int orig = oldPinyin.length() / 2;
				for (int i = 0; i < orig; i++) {
//					System.out.printf("[%d][%d]<=null\n", orig - i, i);
					queryResultD[orig - i][i] = null;
					queryResultL[orig - i][i] = null;
				}
				oldPinyin = pinyin;
				return;
			}
		} finally {
		}

		try {
			if (oldPinyin.endsWith(pinyin) && (oldPinyin.length() > pinyin.length())) {
//				System.out.println("pop");
				final int orig = oldPinyin.length() / 2, pop = orig - pinyin.length() / 2;
				for (int i = 1; i <= orig; i++) {
					for (int j = 0; j <= orig - i - pop; j++) {
//						System.out.printf("[%d][%d]<=[%d][%d]\n", i, j, i, j + pop);
						queryResultD[i][j] = queryResultD[i][j + pop];
						queryResultL[i][j] = queryResultL[i][j + pop];
					}
					for (int x = orig - i - pop + 1, j = x < 0 ? 0 : x; j <= orig - i; j++) {
//						System.out.printf("[%d][%d]<=null\n", i, j);
						queryResultD[i][j] = null;
						queryResultL[i][j] = null;
					}
				}
				oldPinyin = pinyin;
				return;
			}
		} finally {
		}

		throw new Exception("no matched case");
	}

	public static void makeSeparatorAnswer() throws Exception {
		boolean found;
		int counter, length = pinyin.length() / 2;
		for (int[] a : separator[length - 1]) {
			found = true;
			counter = 0;
			for (int b : a) {
				if (queryResultL[b][counter] == null && queryResultD[b][counter] == null) {
					found = false;
					break;
				}
				counter += b;
			}
			if (found) {
				separatorAnswer = a;
				return;
			}
		}
		throw new Exception("No matched separator");
	}

	public static void makeSentence() throws Exception {
		StringBuffer sb = new StringBuffer();
		int counter = 0;
		for (int i : separatorAnswer) {
			sb.append(queryResultL[i][counter] == null ? queryResultD[i][counter].getFirst() : queryResultL[i][counter].getFirst());
			counter += i;
		}
		sentence = sb.toString();
		if (sentence.length() != counter) throw new Exception("queryResult item length not matched");
	}

	public static void makeCandidate() {
		final int length = pinyin.length() / 2;
		candidateLeft = new LinkedList<String>();
		candidateRight = new LinkedList<String>();
		for (int i = length - 1; i > 0; i--)
			if (queryResultD[i][0] != null)
				for (final String s : queryResultD[i][0])
					candidateLeft.addLast(s);
		for (int i = length; i > 0; i--)
			if (queryResultD[i][length - i] != null)
				for (final String s : queryResultD[i][length - i])
					candidateRight.addLast(s);
	}

	public static void query() throws Exception { // For case add 1 chara
		long timer=System.nanoTime();
		StringBuilder sb = new StringBuilder();
		String ziSub;
		int ziLen = pinyin.length() / 2, pinyinLen = pinyin.length();
		if (ziLen != ziLock.length() || ziLen != ziOrig.length()) throw new Exception("ziLen != ziLock.len/2");

		sb.append(s1).append(ziLock.length() > 4 ? type[0] : type[ziLock.length()])
				.append(s2)
				.append(pinyin)
				.append(s3)
				.append(ziLock)
				.append(s4);
		for (int i = 1; i < ziLen; i++) {
			ziSub = ziLock.substring(i, ziLen);
			sb.append(s5).append("\n").append(s1).append(ziSub.length() > 4 ? type[0] : type[ziSub.length()])
					.append(s2)
					.append(pinyin.substring(i + i, pinyinLen))
					.append(s3)
					.append(ziLock.substring(i, ziLen))
					.append(s4);
		}
		sb.append(s6);
		long stop=System.nanoTime();
		System.out.print("building query string");
		System.out.println((stop-timer)/1000);
//		System.out.println(sb.toString());

		Cursor c = conn.executeQuery(sb.toString());
		while (c.next()) {
			int length = c.getInt(0), start = ziLen - length;
			if (queryResultD[length][start] == null) queryResultD[length][start] = new LinkedList<String>();
			queryResultD[c.getInt(0)][ziLen - c.getInt(0)].add(c.getString(1));
		}

	}
}
